<?php
$conn = mysqli_connect('localhost', 'root', '', 'pskd_7') 
or die("<h3>MySQL connection is failed.</h3><br>"); 
?>
