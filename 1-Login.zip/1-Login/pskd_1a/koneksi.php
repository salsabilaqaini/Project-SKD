<?php
$conn = mysqli_connect('localhost', 'root', '', 'pskd01') or die("<h3>MySQL connection is failed.</h3><br>"); 

?>