<?php
//Koneksi PHP
$koneksi = mysqli_connect('localhost', 'root', '', 'pskd') or die("<h3>MySQL connection is failed.</h3><br>"); 

?>