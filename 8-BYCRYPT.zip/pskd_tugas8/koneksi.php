<?php
$conn = mysqli_connect('localhost', 'root', '', 'akun') 
or die("<h3>MySQL connection is failed.</h3><br>"); 
?>
