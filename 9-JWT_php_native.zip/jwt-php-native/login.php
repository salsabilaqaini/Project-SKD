<?php 
// Import script autoload agar bisa menggunakan library
require_once('./vendor/autoload.php');
// Import library
use Firebase\JWT\JWT;
use Dotenv\Dotenv;
//load custom environment
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Atur content type agar response yang dikirim ke user dibaca sebagai JSON
header('Content-Type: application/json');

// Validasi Method Request
// Cek method request apakah POST atau tidak
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    exit();
}

// Validasi format data
// Ambil JSON yang dikirim oleh user
$json = file_get_contents('php://input');
// Decode json tersebut agar mudah mengambil nilainya
$input = json_decode($json);
// Jika tidak ada data email atau password
if(!isset($input->email) || !isset($input->password)) {
    http_response_code(400);
    exit();
}

// Otentifikasi User
// data mock/dummy, bisa diganti dengan data dari database
$user = [
    'email' => 'salsabilaft@gmail.com',
    'password' => 'cobacoba'
];

//jika email atau password tidak sesuai
if($input->email !== $user['email'] || $input->password !== $user['password']) {
    echo json_encode([
        'message' => 'Email atau Password tidak sesuai'
    ]);
    exit();
}

//Buat variabel untuk menyimpan waktu kadaluarsa access tokennya
// 15 * 60(detik) = 15 menit
$expired_time = $time() + (15 * 60);

// Buat variabel payload yang mana akan jadi payload token kita
$payload = [
    'email' => $input->email,
    'exp' => $expired_time
];

// Generate token menggunakan library-nya, dan kirim ke user
$access_token = JWT::encode($payload, $_ENV['ACCESS_TOKEN_SECRET']);
echo json_encode([
    'accessToken' => $access_token,
    'expiry' => date(DATE_ISO8601, $expired_time)
]);

// Menambahkan refresh token di Http-only Cookie
// Ubah waktu kadaluarsa lebih lama (1 jam)
$payload['exp'] = time() + (60 * 60);
$resfresh_token = JWT::encode($payload, $_ENV[REFRESH_TOKEN_SECRET]);
// Simpan refresh token di http-only cookie
setcookie('refreshToken', $resfresh_token, $payload['exp'], '', '',false, true);
